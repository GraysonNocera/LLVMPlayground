#include<stdio.h>

int main(void) {
    int a;
    int b;
    int c;
    int d;
    a = getchar();
    b = 0;
    c = a != b;
    d = b / c;
    return 0;
}