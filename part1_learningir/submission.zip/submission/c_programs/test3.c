#include <stdio.h>

int main(void) {
    int a;
    int b;
    int c;
    int d;
    a = getchar();
    b = 0;
    if (a > 100) {
        d = a / b;
    } else {
        c = b / a;
    }

    return 0;
}